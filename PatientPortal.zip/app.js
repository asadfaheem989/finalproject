const express = require('express');
const app = express();
const moment = require('moment');
app.locals.moment = require('moment');
const port = 4444;
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const passport = require('passport');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const flash = require('connect-flash');
var cron = require('node-cron');


const User = require('./app/user');
const Appointment = require('./app/appointment');
const sendText = require("./app/sendtext")

mongoose.connect('mongodb://superman:lazereye@localhost:27017/patientportal?authSource=admin');

app.use(express.static('public'))
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(cookieParser());
app.use(flash());
app.use(session({
    secret: 'doctordoctorjokes',
    resave: true,
    saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session());

app.set('view engine', 'pug')

require('./app/routes.js')(app, passport);
require('./app/passportz.js')(passport);

cron.schedule('0 0 0 * * *', function(){
    console.log('running cron task every day at midnight');
    Appointment.find({}).exec(function(err,appointments){
        if(err) {
            console.log("mongodb error")
            console.log(err)
        }
        else {
            today = moment()
            appointments.forEach(function(appointment) {
                if(moment(appointment.date).isSame(today,"day")) {
                    sendText("You Have an appointment today at:" + appointment.date)
                }
            })
        }
    })
  });

app.listen(port, function () {
    console.log('Patient Portal Healing The World On Port:' + port)
})