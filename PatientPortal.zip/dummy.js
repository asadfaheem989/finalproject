const mongoose = require('mongoose');
const User = require('./app/user.js');
const bcrypt = require('bcrypt-nodejs');
mongoose.connect('mongodb://superman:lazereye@localhost:27017/patientportal?authSource=admin');

let patient = new User({
    email: "shawn@shawn.com",
    password: bcrypt.hashSync("shawn", bcrypt.genSaltSync(8), null),
    role: "patient",
})

let hospital = new User({
    email: "shane@shane.com",
    password: bcrypt.hashSync("shane", bcrypt.genSaltSync(8), null),
    role: "hospital",
})

patient.save(function (err, patient) {
    if (err) {
        console.log("error saving patient")
        console.log(err)
    } else {
        console.log("Woo Added patient")
    }
})

hospital.save(function (err, hospital) {
    if (err) {
        console.log("error saving hospital")
        console.log(err)
    } else {
        console.log("Woo Added hospital")
    }
})