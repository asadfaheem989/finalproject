const mongoose = require('mongoose');

let appointmentSchema = mongoose.Schema({
    patient: String,
    date: String,
    status: String,
})

module.exports = mongoose.model("Appointment",appointmentSchema);