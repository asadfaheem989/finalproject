const User = require('../app/user');
const Appointment = require('../app/appointment');
const sendText = require("../app/sendtext")
const bcrypt = require('bcrypt-nodejs');
const moment = require('moment');

module.exports = function (app, passport) {

    app.get('/', function (req, res) {
        res.render("home", {
            user: req.user ? req.user : null,
        });
    })

    //----------Patient----------

    app.get('/patient', isLoggedIn, hasRole("patient"), function (req, res) {
        res.render("pdash", {
            user: req.user,
            pagetitle: "Patient - Home"
        });
    })

    app.get('/patient/login', function (req, res) {
        res.render("plogin", {
            flashes: req.flash('login')
        });
    })

    app.post('/patient/login', passport.authenticate('local-login', {
        successRedirect: '/patient',
        failureRedirect: '/patient/login'
    }))

    app.get('/patient/appointments', isLoggedIn, hasRole("patient"), function (req, res) {

        Appointment.find({
            patient: req.user._id
        }).exec(function (err, appointments) {
            if (err) {
                console.log("mongodb error");
                console.log(err);
            } else {
                res.render("pappointments", {
                    user: req.user,
                    pagetitle: "Patient - Appointments",
                    appointments: appointments,
                })
            }
        })

    })

    app.get('/patient/appointments/add', isLoggedIn, hasRole("patient"), function (req, res) {
        res.render("padduserappointment", {
            user: req.user,
            pagetitle: "Patient - Add Appointment",
            flashes: req.flash("appointment")
        })
    })

    app.post('/patient/appointments/add', isLoggedIn, hasRole("patient"), function (req, res) {
        let appdate = req.body.date
        let appdatemoment = moment(appdate);
        let today = moment();

        if (appdatemoment.isSameOrAfter(today, "second") &&
            appdatemoment.isSameOrAfter(today, "minute") &&
            appdatemoment.isSameOrAfter(today, "hour") && appdatemoment.isSameOrAfter(today, "day") && appdatemoment.isSameOrAfter(today, "month") && appdatemoment.isSameOrAfter(today, "year")) {

            let addappoint = new Appointment({
                patient: req.user._id,
                date: appdate,
                status: "pending"
            })

            addappoint.save(function (err, appointment) {
                if (err) {
                    console.log("mongodb error")
                    console.log(err)
                } else {
                    sendText("Scheduled Appointment For" + appointment.date);
                    res.redirect("/patient/appointments/")
                }
            })

        } else {
            req.flash("appointment", "Appointment Can Not Be In The Past")
            res.redirect("/patient/appointments/add")
        }

    })

    app.post("/patient/selfcheckin", isLoggedIn, hasRole("patient"), function (req, res) {
        let appid = req.body.appid
        Appointment.findOne({
            _id: appid
        }).exec(function (err, appointment) {
            if (err) {
                console.log("mongodb error");
                console.log(err);
            } else {

                let today = moment();
                let appdate = moment(appointment.date)

                if (!(today.isAfter(appdate))) {

                    if (appointment.status == "pending") {
                        appointment.status = "arrived"

                        appointment.save(function (err, updatedappointment) {
                            if (err) {
                                console.log("mongodb error");
                                console.log(err);

                            } else {
                                res.redirect("/patient/appointments")
                            }
                        })
                    } else {
                        res.redirect("/")
                    }

                } else {
                    res.redirect("/")
                }


            }
        })
    })

    app.get('/patient/logout', function (req, res) {
        req.logout();
        res.redirect('/');
    })

    //----------Hospital----------

    app.get('/hospital', isLoggedIn, hasRole("hospital"), function (req, res) {
        res.render("hdash", {
            user: req.user,
            pagetitle: "Hospital - Home"
        });
    })

    app.get('/hospital/login', function (req, res) {
        res.render("hlogin", {
            flashes: req.flash('login')
        });
    })

    app.get('/hospital/patients', isLoggedIn, hasRole("hospital"), function (req, res) {
        User.find({
            role: "patient"
        }).exec(function (err, patients) {
            if (err) {
                console.log("mongodb error");
                console.log(err);
            } else {
                res.render("hpatients", {
                    user: req.user,
                    patients: patients,
                    pagetitle: "Hospital - Patients",
                    flashes: req.flash('add')
                })
            }
        })
    })

    app.get('/hospital/patient/add', isLoggedIn, hasRole("hospital"), function (req, res) {
        res.render("hpatientform", {
            user: req.user,
            pagetitle: "Hospital - Add Patient",
            flashes: req.flash('add')
        })
    })

    app.post('/hospital/patient/add', isLoggedIn, hasRole("hospital"), function (req, res) {
        let newemail = req.body.email;

        User.findOne({
            email: newemail
        }).exec(function (err, user) {
            if (err) {
                console.log("mongodb error")
                console.log(err)
            } else {
                if (!user) {
                    let newpass = randomPass(8);
                    let newpatient = new User({
                        email: newemail,
                        password: bcrypt.hashSync(newpass, bcrypt.genSaltSync(8), null),
                        role: "patient",
                    })

                    newpatient.save(function (err, patient) {
                        if (err) {
                            console.log("error saving patient")
                            console.log(err)
                        } else {
                            console.log("Hospital Staff Added patient")
                            req.flash('add', 'user added with email: ' + newemail + ' and password: ' + newpass + " please add an Initial Appointment!")
                            res.redirect("/hospital/patients")
                        }
                    })
                } else {
                    req.flash('add', 'patient already exsists')
                    res.redirect("/hospital/patient/add")
                }
            }
        })

    })

    app.get('/hospital/appointments', isLoggedIn, hasRole("hospital"), function (req, res) {

        Appointment.find({}).exec(function (err, appointments) {
            if (err) {
                console.log("mongodb error");
                console.log(err);
            } else {
                res.render("happointments", {
                    user: req.user,
                    appointments: appointments,
                    pagetitle: "Hospital - Appointments"
                })
            }
        })
    })

    app.get('/hospital/appointments/:patient', isLoggedIn, hasRole("hospital"), function (req, res) {

        let patientid = req.params.patient

        Appointment.find({
            patient: patientid
        }).exec(function (err, appointments) {
            if (err) {
                console.log("mongodb error");
                console.log(err);
            } else {
                res.render("huserappointments", {
                    user: req.user,
                    appointments: appointments,
                    pagetitle: "Hospital - Appointments for: " + patientid,
                    patientid: patientid

                })
            }
        })
    })

    app.get("/hospital/appointments/:patient/add", isLoggedIn, hasRole("hospital"), function (req, res) {
        let patientid = req.params.patient

        res.render("hadduserappointment", {
            user: req.user,
            pagetitle: "Hospital -Add Appointment for: " + patientid,
            patientid: patientid,
            flashes: req.flash("appointment")
        })
    })

    app.get("/hospital/appointment/:appointmenttoedit/edit", isLoggedIn, hasRole("hospital"), function (req, res) {

        let appointmenttoedit = req.params.appointmenttoedit

        Appointment.findOne({
            _id: appointmenttoedit
        }).exec(function (err, appointment) {
            if (err) {
                console.log("mongodb error");
                console.log(err);
            } else {
                res.render("hedituserappointment", {
                    user: req.user,
                    pagetitle: "Hospital -Edit Appointment: " + appointment.patient,
                    flashes: req.flash("appointment"),
                    appointment: appointment
                })
            }
        })
    })

    app.post("/hospital/appointment/:appointmenttoedit/edit", isLoggedIn, hasRole("hospital"), function (req, res) {
        let appointmenttoedit = req.params.appointmenttoedit
        let editstatus = req.body.status
        let editdate = req.body.date


        Appointment.findOne({
            _id: appointmenttoedit
        }).exec(function (err, appointment) {
            if (err) {
                console.log("mongodb error");
                console.log(err);
            }
            else {
                appointment.date = editdate
                appointment.status = editstatus

                appointment.save(function(err,appointment) {
                    if(err) {
                        console.log("error updating appointment")
                        console.log(err)
                    }
                    else {
                        res.redirect("/hospital/appointments");
                    }
                })
            }
        })
    })

    app.post("/hospital/appointments/:patient/add", isLoggedIn, hasRole("hospital"), function (req, res) {
        let patientid = req.params.patient
        let appointmentdate = req.body.date
        let appointmentstatus = req.body.status
        let appointmentmoment = moment(appointmentdate)
        let today = moment();

        if (appointmentmoment.isSameOrAfter(today, "second") && appointmentmoment.isSameOrAfter(today, "minute") && appointmentmoment.isSameOrAfter(today, "hour") && appointmentmoment.isSameOrAfter(today, "day") && appointmentmoment.isSameOrAfter(today, "month") && appointmentmoment.isSameOrAfter(today, "year")) {
            let addappointment = new Appointment({
                patient: patientid,
                date: appointmentdate,
                status: appointmentstatus
            })

            addappointment.save(function (err, appointment) {
                if (err) {
                    console.log("error saving appointment")
                    console.log(err)
                } else {
                    User.findOne({
                        _id: patientid
                    }).exec(function (err, user) {
                        if (err) {
                            console.log("mongodb error");
                            console.log(err);
                        } else {
                            user.appointments.push(appointment._id)

                            user.save(function (err, updateduser) {
                                if (err) {
                                    console.log("mongodb error");
                                    console.log(err);
                                } else {
                                    res.redirect("/hospital/appointments/" + patientid)
                                }
                            })
                        }
                    })
                }
            })


        } else {
            req.flash("appointment", "Appointment Can Not Be In The Past")
            res.redirect("/hospital/appointments/" + patientid + "/add")
        }
    })

    app.post('/hospital/login', passport.authenticate('local-login', {
        successRedirect: '/hospital',
        failureRedirect: '/hospital/login'
    }))

    app.get('/hospital/logout', function (req, res) {
        req.logout();
        res.redirect('/');
    })

    //Other

    app.get('*', function (req, res) {
        res.render("error", {
            user: req.user ? req.user : null,
            errormsg: "404 Page Not Found"
        });
    })

    function isLoggedIn(req, res, next) {

        if (req.isAuthenticated()) {
            return next();
        }

        res.redirect('/');
    }

    function hasRole(role) {
        return function (req, res, next) {
            if (req.user.role == role) {
                return next()
            }

            res.render("error", {
                errormsg: "you are not logged in as a" + role
            });
        }
    }

    function randomPass(length) {
        let chars = "abcdefghijklmnopqrstuvwxyz!@#$%^&*()-+<>ABCDEFGHIJKLMNOP1234567890"
        let pass = ""

        for (var i = 0; i < length; i++) {
            var p = Math.floor(Math.random() * (chars.length - 0 + 1)) + 0
            pass += chars[p];
        }

        return pass;
    }

}