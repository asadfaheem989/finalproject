module.exports = function sendText(text) {
    console.log("Sent Text:")
    console.log(text)
}